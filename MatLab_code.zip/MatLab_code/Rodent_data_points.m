BED1_morrisxb=[22,40,80]; BED2_morrisxb=[75,78,49];% Morris et. al X-B
BED1_morrisbb=[82]; BED2_morrisbb=[54];% Morris et. al B-B
BED1_wong140=[47,71,89]; BED2_wong140=[68.5,51.5,48.1]; % Wong and Hao 140 days
BED1_wong196=[47,71,89]; BED2_wong196=[68.2,56.4,61.8]; % Wong and Hao 196 days
BED1_wong93=[25,50,75,90]; BED2_wong93=[81,70,58,42]; % Wong et.al (1993)
BED1_vd_Kogel1982=[67.7,66.5]; BED2_vd_Kogel1982=[67.7,66.5]; % Van der Kogel et. al (1982)
BED1_vd_Kogel1991=[50,70,90]; BED2_vd_Kogel1991=[90,71.1,35]; % Van der Kogel et. al (1991)

% hold on
% plot(BED1_morrisxb,BED2_morrisxb,'r*')
% 
% plot(BED1_morrisbb,BED2_morrisbb,'rs')
% 
% plot(BED1_wong140,BED2_wong140,'rd')
% 
% plot(BED1_wong196,BED2_wong196,'r^')
% 
% plot(BED1_wong93,BED2_wong93,'r+')
% 
% plot(BED1_vd_Kogel1982,BED2_vd_Kogel1982,'rx')
% 
% plot(BED1_vd_Kogel1991,BED2_vd_Kogel1991,'rv')
% 
% plot(x1,y1,'--r')